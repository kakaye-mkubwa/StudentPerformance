<?php

header("Location: UI/pages/list-performance.php");
exit;