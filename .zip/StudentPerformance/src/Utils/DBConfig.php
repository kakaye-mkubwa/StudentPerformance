<?php
namespace App\Utils;

class DBConfig{
    const DB_USERNAME="root";
    const DB_NAME="school_grade_attendance";
    const DB_SERVER="localhost";
    const DB_PASS="123456";
}
